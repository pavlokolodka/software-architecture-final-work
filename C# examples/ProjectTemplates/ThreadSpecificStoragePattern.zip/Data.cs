﻿namespace $safeprojectname$
{
    public class Data
    {
        public string Value { get; set; } = "Default Value";
    }
}
