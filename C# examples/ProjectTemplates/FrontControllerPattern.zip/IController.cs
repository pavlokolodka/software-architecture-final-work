﻿namespace $safeprojectname$
{
    public interface IController
    {
        void ProcessRequest();
    }
}
