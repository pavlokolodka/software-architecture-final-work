﻿namespace $safeprojectname$
{
    public class View
    {
        public void Show()
        {
            Console.WriteLine("Displaying Home Page");
        }
    }
}
