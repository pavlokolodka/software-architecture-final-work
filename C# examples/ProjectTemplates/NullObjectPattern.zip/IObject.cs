﻿namespace $safeprojectname$
{
    public class RealObject : IObject
    {
        public void Operation()
        {
            Console.WriteLine("RealObject Operation");
        }
    }
}
