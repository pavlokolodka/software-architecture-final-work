﻿namespace $safeprojectname$
{
    public class NullObject : IObject
    {
        public void Operation()
        {
        }
    }
}
